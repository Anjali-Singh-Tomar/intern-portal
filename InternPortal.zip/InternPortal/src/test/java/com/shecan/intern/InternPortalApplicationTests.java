package com.shecan.intern;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
